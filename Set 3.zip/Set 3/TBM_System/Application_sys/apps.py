from django.apps import AppConfig


class ApplicationSysConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Application_sys'
